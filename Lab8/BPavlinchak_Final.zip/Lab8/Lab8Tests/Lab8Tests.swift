//
//  Lab8Tests.swift
//  Lab8Tests
//
//  Created by Brenna Pavlinchak on 11/22/24.
//

import Testing
@testable import Lab8

struct Lab8Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
