//
//  SettingsTableViewCell.swift
//  Lab8
//
//  Created by Brenna Pavlinchak on 11/23/24.
//

import UIKit

import UIKit

class ThemeTableViewCell: UITableViewCell
{
    @IBOutlet weak var themeLabel: UILabel!
    @IBOutlet weak var checkmarkImageView: UIImageView!
}
