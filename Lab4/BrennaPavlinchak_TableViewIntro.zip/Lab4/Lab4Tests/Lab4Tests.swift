//
//  Lab4Tests.swift
//  Lab4Tests
//
//  Created by Brenna Pavlinchak on 11/11/24.
//

import Testing
@testable import Lab4

struct Lab4Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
