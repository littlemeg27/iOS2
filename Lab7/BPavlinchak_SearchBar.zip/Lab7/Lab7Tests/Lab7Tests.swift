//
//  Lab7Tests.swift
//  Lab7Tests
//
//  Created by Brenna Pavlinchak on 11/22/24.
//

import Testing
@testable import Lab7

struct Lab7Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
