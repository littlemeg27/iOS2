//
//  Lab2Tests.swift
//  Lab2Tests
//
//  Created by Brenna Pavlinchak on 11/5/24.
//

import Testing
@testable import Lab2

struct Lab2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
