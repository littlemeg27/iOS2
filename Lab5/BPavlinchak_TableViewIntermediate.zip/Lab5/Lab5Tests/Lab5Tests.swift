//
//  Lab5Tests.swift
//  Lab5Tests
//
//  Created by Brenna Pavlinchak on 11/16/24.
//

import Testing
@testable import Lab5

struct Lab5Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
