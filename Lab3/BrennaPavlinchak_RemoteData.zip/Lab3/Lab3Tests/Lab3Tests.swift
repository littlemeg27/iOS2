//
//  Lab3Tests.swift
//  Lab3Tests
//
//  Created by Brenna Pavlinchak on 11/10/24.
//

import Testing
@testable import Lab3

struct Lab3Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
